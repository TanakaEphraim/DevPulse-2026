# Audience Personas

## Persona 1 — Tariro, Junior Developer
**Age:** 23  
**Goal:** Find better opportunities and build industry connections  
**Pain Points:** Limited network, uncertainty about which skills employers want  
**Best Messaging:** “Meet employers, developers and founders in one place.”

## Persona 2 — Rudo, University Student
**Age:** 21  
**Goal:** Learn practical tech and career skills  
**Pain Points:** Too much theory, not enough exposure to industry  
**Best Messaging:** “Learn from people building real products and careers.”

## Persona 3 — Kevin, Early-Stage Founder
**Age:** 29  
**Goal:** Meet collaborators, customers and ecosystem partners  
**Pain Points:** Limited visibility and weak access to decision-makers  
**Best Messaging:** “Connect with builders, talent and potential partners.”

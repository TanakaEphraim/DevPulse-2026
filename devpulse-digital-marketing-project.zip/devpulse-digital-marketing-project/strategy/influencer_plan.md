# Influencer & Ambassador Plan

## Objective
Use trusted technology and career voices to increase event credibility and registrations.

## Creator Types
- Tech educators
- Developer creators
- Startup founders
- Career coaches
- University campus ambassadors

## Content Deliverables
Each creator receives:
- 1 announcement post
- 1 short video
- 3 story frames
- 1 reminder post near registration deadline

## Suggested Tracking
Each partner receives:
- Unique UTM link
- Unique referral code
- Registration dashboard tracking

## KPIs
- Link clicks
- Cost per lead
- Registrations
- Referral conversion rate
- Video views
- Saves and shares

# Email Nurture Sequence

## Email 1 — Welcome
**Subject:** You’re on the DevPulse list

Thanks for joining the DevPulse community.

Over the next few weeks, we’ll share the people, sessions and opportunities waiting for you at DevPulse 2026.

**CTA:** Explore the Event

---

## Email 2 — Value
**Subject:** What you’ll actually get from DevPulse

This isn’t another event where you sit, listen and leave.

You’ll gain:
- Practical career and technology insights
- New professional connections
- Exposure to founders and employers
- New ideas for your next project or move

**CTA:** See What’s Included

---

## Email 3 — Social Proof
**Subject:** The right room changes everything

A strong network can shorten the distance between where you are and where you want to go.

DevPulse puts ambitious people in the same room.

**CTA:** Reserve Your Spot

---

## Email 4 — Urgency
**Subject:** Registration closes soon

DevPulse 2026 registration is almost closed.

If you’ve been waiting for the right time, this is it.

**CTA:** Register Now

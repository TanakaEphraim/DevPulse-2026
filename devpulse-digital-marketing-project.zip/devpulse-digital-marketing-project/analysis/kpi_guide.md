# Lead Generation KPI Guide

| KPI | Formula | Purpose |
|---|---|---|
| CTR | Clicks / Impressions | Measures ad relevance |
| CPC | Spend / Clicks | Measures traffic cost |
| Lead Conversion Rate | Leads / Clicks | Measures landing-page effectiveness |
| CPL | Spend / Leads | Measures lead acquisition efficiency |
| Registration Rate | Registrations / Leads | Measures nurture and conversion quality |

## A/B Testing
Landing page Variant B outperformed Variant A in the simulated experiment.

The test demonstrates how campaign decisions can be based on conversion data rather than preference.

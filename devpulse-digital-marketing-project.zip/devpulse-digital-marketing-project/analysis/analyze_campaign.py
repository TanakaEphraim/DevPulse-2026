from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
df = pd.read_csv(ROOT / "data" / "campaign_performance.csv")

summary = df.groupby("channel", as_index=False).agg(
    spend_usd=("spend_usd","sum"),
    impressions=("impressions","sum"),
    clicks=("clicks","sum"),
    leads=("leads","sum"),
    registrations=("registrations","sum")
)

summary["ctr"] = summary["clicks"] / summary["impressions"]
summary["cpc_usd"] = summary["spend_usd"] / summary["clicks"]
summary["cpl_usd"] = summary["spend_usd"] / summary["leads"]
summary["lead_conversion_rate"] = summary["leads"] / summary["clicks"]
summary["registration_rate"] = summary["registrations"] / summary["leads"]

print("\nDEV PULSE CAMPAIGN PERFORMANCE\n")
print(summary.round(3).to_string(index=False))

best_cpl = summary.loc[summary["cpl_usd"].idxmin()]
best_reg = summary.loc[summary["registration_rate"].idxmax()]

print(f"\nLowest CPL: {best_cpl['channel']} (${best_cpl['cpl_usd']:.2f})")
print(f"Best lead-to-registration rate: {best_reg['channel']} ({best_reg['registration_rate']:.1%})")

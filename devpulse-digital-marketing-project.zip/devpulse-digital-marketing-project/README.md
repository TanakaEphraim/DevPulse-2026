# DevPulse 2026 — Digital Marketing Lead Generation Project

A complete digital marketing portfolio case study for a fictional technology and career event.

This project demonstrates how to plan, launch, measure and optimize a multi-channel lead-generation campaign.

> **Disclaimer:** DevPulse 2026 is fictional. All performance data is simulated for educational and portfolio purposes.

## What This Project Demonstrates

- Campaign strategy
- Customer personas
- Paid media planning
- Social media content
- Email lead nurturing
- Influencer marketing
- Landing-page copywriting
- A/B testing
- Marketing funnel analysis
- Python campaign analytics
- KPI dashboard design

## Campaign Results

| KPI | Result |
|---|---:|
| Campaign Duration | 60 days |
| Total Spend | $17,977.96 |
| Impressions | 1,615,495 |
| Clicks | 69,464 |
| Leads | 7,601 |
| Registrations | 2,098 |
| Cost Per Lead | $2.37 |
| Lead → Registration Rate | 27.6% |

## Key Insight

The most cost-efficient simulated lead source was **Email**, with a CPL of **$0.17**.

The landing-page A/B test also showed that **Variant B — “Get Hired. Get Connected. Get Ahead.”** produced approximately **25.0% uplift** over Variant A.

## Repository Structure

```text
devpulse-digital-marketing-project/
├── README.md
├── LICENSE
├── requirements.txt
├── strategy/
│   ├── campaign_strategy.md
│   ├── audience_personas.md
│   └── influencer_plan.md
├── content/
│   ├── content_calendar.csv
│   ├── ad_copy.md
│   └── email_sequence.md
├── data/
│   └── campaign_performance.csv
├── analysis/
│   ├── analyze_campaign.py
│   ├── channel_summary.csv
│   ├── landing_page_ab_test.csv
│   └── kpi_guide.md
├── assets/
│   ├── cpl_by_channel.png
│   ├── lead_registration_trend.png
│   └── ab_test_results.png
├── landing-page/
│   └── index.html
└── dashboard/
    └── index.html
```

## Campaign Funnel

**Awareness → Website Visit → Lead → Registration → Referral**

The campaign uses:
- LinkedIn Ads
- Meta Ads
- Google Search
- Email Marketing
- Influencer / Ambassador Marketing

## Landing Page Experiment

Two headline variants were tested:

**Variant A:** Build Your Future in Tech  
**Variant B:** Get Hired. Get Connected. Get Ahead.

The project includes simulated visitor, lead and conversion-rate data to show how landing-page optimization can influence campaign performance.

![A/B Test](assets/ab_test_results.png)

## Campaign Analytics

### Cost Per Lead by Channel
![CPL by Channel](assets/cpl_by_channel.png)

### Lead and Registration Trend
![Lead Trend](assets/lead_registration_trend.png)

## Run the Analysis

```bash
pip install -r requirements.txt
python analysis/analyze_campaign.py
```

## View the Landing Page

Open:

```text
landing-page/index.html
```

## View the Marketing Dashboard

Open:

```text
dashboard/index.html
```

Both pages can be published using GitHub Pages.

## Portfolio Description

> Developed a full digital marketing lead-generation campaign for a fictional technology event, including audience segmentation, paid advertising, social content, influencer strategy, email nurturing, landing-page optimization and campaign analytics. Used Python to evaluate channel performance, CPL, funnel conversion and A/B testing results.

## Skills Demonstrated

**Digital Marketing:** Campaign Strategy, Lead Generation, Paid Media, Content Marketing, Email Marketing, Influencer Marketing, Conversion Optimization

**Analytics:** CTR, CPC, CPL, Funnel Conversion, A/B Testing, Channel Performance

**Technical:** Python, Pandas, Matplotlib, HTML, CSS, CSV
